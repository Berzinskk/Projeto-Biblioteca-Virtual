﻿namespace WinFormsApp1
{
    internal class RegistroForm
    {
        public RegistroForm()
        {
        }

        internal void ShowDialog()
        {
            throw new NotImplementedException();
        }
    }
}